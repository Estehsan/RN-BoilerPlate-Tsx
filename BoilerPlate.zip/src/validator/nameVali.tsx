export function nameVali(name) {
  if (!name) return "Name can't be empty.";
  return '';
}
