import nameVali from './nameVali';
import emailVali from './emailVali';
import passVali from './passVali';

export {nameVali, emailVali, passVali};
