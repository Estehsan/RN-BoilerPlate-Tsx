import GetStarted from './GetStarted';
import Login from './Login';
import Register from './Register';
import Loading from './Loading';
import Reset from './Reset';

export {GetStarted, Login, Register, Loading, Reset};
