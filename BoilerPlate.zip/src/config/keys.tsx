// Replace with your own firebase config!
export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyC0P4wtHZSsAEY9BkuKvPOGVWRYNyYFqDA',
  authDomain: 'tsxfirebase.firebaseapp.com',
  projectId: 'tsxfirebase',
  storageBucket: 'tsxfirebase.appspot.com',
  messagingSenderId: '75118731471',
  appId: '1:75118731471:web:a2944df4d6b0183a2a17ba',
  measurementId: 'G-52MV76YDQJ',
};

// Replace with your own IDs!

// 👇 Google ID's are here 👇
export const WEB_CLIENT_ID =
  '75118731471-aggg9e5o891n3tdscmk62bf9oatevqno.apps.googleusercontent.com';

// 👇 Facebook App key Here 👇
export const APP_KEY = '857933798245745';
