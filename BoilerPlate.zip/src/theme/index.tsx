import {theme} from './theme';

export {theme};
