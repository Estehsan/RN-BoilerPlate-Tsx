import React, {FC} from 'react';
import MainApp from './src/navigation';

const App: FC = () => {
  return (
    <>
      <MainApp />
    </>
  );
};

export default App;
